// (C) Copyright 2017 Frédéric Massart
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.xp')

.factory('$mmaXpGroups', function($mmEvents, $mmSite, $mmGroups, $log, $q, mmaXpGroupChangedEvent) {
    $log = $log.getInstance('$mmaXpGroups');

    var self = {},
        currentGroup = {};

    self.getCourseGroupInfo = function(courseId) {
        return $mmSite.read('local_xp_get_course_group_info', {courseid: courseId}).then(function(data) {
            return data;
        });
    }

    self.getCourseGroupMode = function(courseId) {
        var p;

        if (courseId == $mmSite.getSiteHomeId()) {
            p = $q.when($mmGroups.NOGROUPS);
        } else {
            p = self.getCourseGroupInfo(courseId).then(function(course) {
                return course.groupmode;
            });
        }

        return p.then(function(groupmode) {
            $log.debug("Found course " + courseId + " group mode to be: " + groupmode);
            return groupmode;
        }).catch(function() {
            $log.debug("Could not determine group mode of course: " + courseId);
            return $q.reject();
        })
    }

    /**
     * Get the current group ID.
     *
     * @param {Number} courseId The course ID.
     * @return {Promise} Resolved with the group ID, or 0.
     */
    self.getCurrentGroupId = function(courseId) {
        var siteId = $mmSite.getId(),
            groupId;

        if (typeof currentGroup[siteId] === 'undefined') {
            currentGroup[siteId] = {};
        }

        // Always all participants on front page.
        if (courseId == $mmSite.getSiteHomeId()) {
            return $q.when(0);
        }

        // Check whether we have a group stored.
        groupId = currentGroup[siteId][courseId];
        if (typeof groupId === 'undefined') {
            groupId = self.getCourseGroupInfo(courseId).then(function(info) {
                if (info.groupmode == $mmGroups.NOGROUPS) {
                    return 0;
                } else if (info.canaccessallgroups) {
                    return 0;
                }

                // Return the first where a member group, else all participants.
                var memberIn = info.groups.filter(function(group) { return group.ismember; });
                if (memberIn.length && typeof memberIn[0] !== 'undefined') {
                    return memberIn[0].id;
                }
                return 0;
            });
        }

        // Store and return the chosen group.
        return $q.when(groupId).then(function(groupId) {
            currentGroup[siteId][courseId] = groupId;
            return groupId;
        });
    }

    self.isCourseUsingGroups = function(courseId) {
        return self.getCourseGroupMode(courseId).then(function(groupmode) {
            return groupmode != $mmGroups.NOGROUPS;
        });
    }

    self.setCurrentGroupId = function(courseId, groupId) {
        var siteId = $mmSite.getId()
        if (typeof currentGroup[siteId] === 'undefined') {
            currentGroup[siteId] = {};
        }
        currentGroup[siteId][courseId] = groupId || 0;

        // Trigger event.
        $mmEvents.trigger(mmaXpGroupChangedEvent, {
            siteId: siteId,
            courseId: courseId,
            groupId: currentGroup[siteId][courseId]
        });

        $log.debug("Setting current group for course " + courseId + " to: " + currentGroup[siteId][courseId]);
    }

    return self;
});
