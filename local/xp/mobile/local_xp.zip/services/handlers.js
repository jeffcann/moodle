// (C) Copyright 2017 Frédéric Massart
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.xp')

.factory('$mmaXpHandlers', function($mmaXp, $q, $log, $mmSite, mmaXpNavIcon) {
    $log = $log.getInstance('$mmaXpHandlers');
    var self = {};

    self.sideMenuNav = function() {
        var self = {};

        /**
         * Check if handler is enabled.
         *
         * @return {Boolean|Promise} True if handler is enabled, false otherwise.
         */
        self.isEnabled = function() {
            $log.debug('sideMenuNav::isEnabled()');
            if ($mmaXp.isPluginEnabled()) {
                return $mmaXp.isVisibleForWholeSite().then(function(enabled) {
                    $log.debug('sideMenuNav::isEnabled() responded: ' + enabled);
                    return enabled;
                });
            }
            $log.debug('sideMenuNav::isEnabled() responded: false');
            return false;
        };

        /**
         * Get the controller.
         *
         * @return {Object}         Controller.
         */
        self.getController = function() {

            /**
             * Courses nav handler controller.
             *
             * @module mm.addons.xp
             * @ngdoc controller
             */
            return function($scope, $state) {
                var courseId = $mmSite.getSiteHomeId();
                $scope.icon = mmaXpNavIcon;
                $scope.title = $mmaXp.getTitle(courseId);
                $scope.class = 'mma-xp-handler';
                $scope.state = 'site.xp';
            };
        };

        return self;
    };

    self.coursesNav = function() {
        var self = {};

        /**
         * Check if handler is enabled.
         *
         * @return {Boolean|Promise} True if handler is enabled, false otherwise.
         */
        self.isEnabled = function() {
            $log.debug('coursesNav::isEnabled()');
            if ($mmaXp.isPluginEnabled()) {
                // Only enabled when not in whole site mode.
                return $mmaXp.isForWholeSite().then(function(enabled) {
                    enabled = !enabled;
                    $log.debug('coursesNav::isEnabled() responded: ' + enabled);
                    return enabled;
                });
            }
            $log.debug('coursesNav::isEnabled() responded: false');
            return false;
        };

        /**
         * Check if handler is enabled for this course.
         *
         * @param  {Number} courseId     Course ID.
         * @param  {Object} accessData   Type of access to the course: default, guest, ...
         * @param  {Object} [navOptions] Course navigation options for current user. See $mmCourses#getUserNavigationOptions.
         * @param  {Object} [admOptions] Course admin options for current user. See $mmCourses#getUserAdministrationOptions.
         * @return {Promise}             True if handler is enabled, false otherwise.
         */
        self.isEnabledForCourse = function(courseId, accessData, navOptions, admOptions) {
            $log.debug('coursesNav::isEnabledForCourse()');
            return $mmaXp.isVisibleForCourse(courseId).then(function(enabled) {
                $log.debug('coursesNav::isEnabledForCourse() responded: ' + enabled);
                return enabled;
            });
        };

        /**
         * Get the controller.
         *
         * @param {Number} courseId Course ID.
         * @return {Object}         Controller.
         */
        self.getController = function(courseId) {

            /**
             * Courses nav handler controller.
             *
             * @module mm.addons.xp
             * @ngdoc controller
             */
            return function($scope, $state) {
                $scope.icon = mmaXpNavIcon;
                $scope.title = $mmaXp.getTitle(courseId);
                $scope.class = 'mma-xp-handler';
                $scope.action = function($event, course) {
                    $event.preventDefault();
                    $event.stopPropagation();
                    $state.go('site.xp', {
                        courseid: course.id
                    });
                };
            };
        };

        return self;
    }

    return self;
});
