// (C) Copyright 2017 Frédéric Massart
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.xp')

.factory('$mmaXp', function($mmWS, $mmSite, $log, $translate, mmaXpContextSystem) {
    $log = $log.getInstance('$mmaXp');

    var self = {},
        optimisticSetupCache = {};

    /**
     * Optimistic setup cache.
     *
     * This is only to be used when Promises are not an option. It should
     * not be used as a storage cache, it's more to retrieve data which
     * was seen before but we cannot afford to use a Promise.
     *
     * @param {Number} courseId The course ID.
     * @return {Object|undefined}
     */
    function getCachedSetup(courseId) {
        return optimisticSetupCache[courseId];
    }

    /**
     * Cache key for setup.
     *
     * @param {Number} courseId The course ID.
     * @return {string}
     */
    function getCacheKeyForSetup(courseId) {
        return 'mmaXp:setup:' + courseId;
    }

    /**
     * Cache key for ladder.
     *
     * @param {Number} courseId The course ID.
     * @param {Number} groupId The group ID.
     * @param {Number} page The page.
     * @param {Number} perpage Per page.
     * @return {string}
     */
    function getCacheKeyForLadder(courseId, groupId, page, perpage) {
        var key = 'mmaXp:ladder:' + courseId + ':' + groupId;
        if (typeof page !== 'undefined') {
            key += ':' + page + ':' + perpage;
        }
        return key;
    }

    /**
     * Cache key for recent activity.
     *
     * @param {Number} courseId The course ID.
     * @return {string}
     */
    function getCacheKeyForRecentActivity(courseId) {
        return 'mmaXp:recentActivity:' + courseId;
    }

    /**
     * Cache key for user state.
     *
     * @param {Number} courseId The course ID.
     * @param {Number} userId The user ID.
     * @return {string}
     */
    function getCacheKeyForUserState(courseId, userId) {
        return 'mmaXp:userState:' + courseId + ':' + userId;
    }

    /**
     * Fix currency URLs.
     *
     * @param {Object} currency The currency.
     * @return {Object}
     */
    function fixCurrencyUrls(currency) {
        if (currency && currency.signurl) {
            currency.signurl = $mmSite.fixPluginfileURL(currency.signurl);
        }
        return currency;
    }

    /**
     * Fix level URLs.
     *
     * @param {Object} level The level.
     * @return {Object}
     */
    function fixLevelUrls(level) {
        if (level && level.badgeurl) {
            level.badgeurl = $mmSite.fixPluginfileURL(level.badgeurl);
        }
        return level;
    }

    /**
     * Fix rank URLs.
     *
     * @param {Object} rank The rank.
     * @return {Object}
     */
    function fixRankUrls(rank) {
        if (rank && rank.state) {
            rank.state = fixLevelUrls(rank.state);
        }
        return rank;
    }

    /**
     * Fix state URLs.
     *
     * @param {Object} state The state.
     * @return {Object}
     */
    function fixStateUrls(state) {
        if (state && state.level) {
            state.level = fixLevelUrls(state.level);
        }
        return state;
    }

    /**
     * Get the levels info.
     *
     * @param {Number} courseId The course ID.
     * @param {Number} [groupId] The group ID.
     * @param {Number} [page] The page.
     * @param {Number} [perpage] Per page.
     * @return {Promise} Resolved with response data.
     */
    self.getLadder = function(courseId, groupId, page, perpage) {
        groupId = groupId || 0;
        page = page || 0;
        perpage = perpage || 20;
        var presets = {
            cacheKey: getCacheKeyForLadder(courseId, groupId, page, perpage)
        };

        $log.debug('Calling ladder method for course, group: ' + courseId + ', ' + groupId);
        return $mmSite.read('local_xp_get_course_world_ladder', {
            courseid: courseId,
            groupid: groupId,
            page: page,
            perpage: perpage
        }, presets).then(function(response) {
            response.ranking = response.ranking.map(function(rank) {
                return fixRankUrls(rank);
            });
            return response;
        });
    }

    /**
     * Get the levels info.
     *
     * @param {Number} courseId The course ID.
     * @return {Promise} Resolved with response data.
     */
    self.getLevelsInfo = function(courseId) {
        $log.debug('Calling levels method for course: ' + courseId);
        return $mmSite.read('local_xp_get_levels_info', {courseid: courseId}).then(function(response) {
            response.levels = response.levels.map(function(level) {
                return fixLevelUrls(level);
            });
            return response;
        });
    }

    /**
     * Get recent activity.
     *
     * @param {Number} courseId The course ID.
     * @return {Promise} Resolved with response data.
     */
    self.getRecentActivity = function(courseId) {
        var presets = {
            cacheKey: getCacheKeyForRecentActivity(courseId)
        };

        $log.debug('Calling recent activity method for course: ' + courseId);
        return $mmSite.read('local_xp_get_recent_activity', {courseid: courseId}, presets).then(function(response) {
            return response;
        });
    };

    /**
     * Get the set-up.
     *
     * @param {Number} courseId The course ID.
     * @return {Promise} Resolved with response data.
     */
    self.getSetup = function(courseId) {
        var presets = {
            cacheKey: getCacheKeyForSetup(courseId)
        };

        $log.debug('Calling setup method for course: ' + courseId);
        return $mmSite.read('local_xp_get_setup', {courseid: courseId}, presets).then(function(response) {
            if (response && response.visuals && response.visuals.currency) {
                response.visuals.currency = fixCurrencyUrls(response.visuals.currency);
            }
            optimisticSetupCache[courseId] = response;
            return response;
        });
    };

    /**
     * Get the title.
     *
     * @param {Number} courseId The course ID.
     * @return {String}
     */
    self.getTitle = function(courseId) {
        var setup = getCachedSetup(courseId);
        if (!setup || !setup.block || !setup.block.title) {
            return $translate.instant('mma.xp.levelup');
        }
        return setup.block.title;
    }

    /**
     * Get the user state.
     *
     * @param {Number} courseId The course ID.
     * @param {Number} userId The user ID.
     * @return {Promise} Resolved with response data.
     */
    self.getUserState = function(courseId,  userId) {
        userId = userId || $mmSite.getUserId();
        var presets = {
            cacheKey: getCacheKeyForUserState(courseId, userId)
        }
        return $mmSite.read('local_xp_get_user_state', {courseid: courseId, userid: userId}, presets).then(function(state) {
            return fixStateUrls(state);
        });
    };

    /**
     * Invalidate ladder cache.
     *
     * @param {Number} courseId The course ID.
     * @param {Number} groupId The group ID.
     * @return {Promise}
     */
    self.invalidateLadderCache = function(courseId, groupId) {
        return $mmSite.invalidateWsCacheForKeyStartingWith(getCacheKeyForLadder(courseId, groupId));
    };

    /**
     * Invalidate recent activity cache.
     *
     * @param {Number} courseId The course ID.
     * @return {Promise}
     */
    self.invalidateRecentActivityCache = function(courseId) {
        return $mmSite.invalidateWsCacheForKey(getCacheKeyForRecentActivity(courseId));
    };

    /**
     * Invalidate setup cache.
     *
     * @param {Number} courseId The course ID.
     * @return {Promise}
     */
    self.invalidateSetupCache = function(courseId) {
        return $mmSite.invalidateWsCacheForKey(getCacheKeyForSetup(courseId));
    };

    /**
     * Invalidate setup cache.
     *
     * @param {Number} courseId The course ID.
     * @return {Promise}
     */
    self.invalidateUserStateCache = function(courseId, userId) {
        userId = userId || $mmSite.getUserId();
        return $mmSite.invalidateWsCacheForKey(getCacheKeyForUserState(courseId, userId));
    };

    /**
     * Returns whether we are in for whole site mode.
     *
     * Fail-safe by returning false when there was an error.
     *
     * @return {Promise} Always resolving to a boolean.
     */
    self.isForWholeSite = function() {
        return self.getSetup($mmSite.getSiteHomeId()).then(function(response) {
            return response.contextmode == mmaXpContextSystem;
        }).catch(function() {
            return false;
        });
    }

    /**
     * Returns whether or not the plugin is enabled for the current site.
     *
     * @return {Boolean}
     */
    self.isPluginEnabled = function() {
        var enabled = false;
        if ($mmSite.isLoggedIn() && $mmSite.wsAvailable('local_xp_get_setup', false)) {
            enabled = true;
        }
        $log.debug(enabled ? 'Plugin is enabled.' : 'Plugin is disabled.');
        return enabled;
    };

    /**
     * Is visible in the course?
     *
     * @return {Promise} Always resolves to a boolean.
     */
    self.isVisibleForCourse = function(courseId) {
        return self.getSetup(courseId).then(function(response) {
            return response.contextmode != mmaXpContextSystem
                && response.block
                && response.block.visible
                && response.perms
                && response.perms.canaccess;
        }).catch(function() {
            return false;
        });
    };

    /**
     * Is visible for the whole site?
     *
     * @return {Promise} Always resolves to a boolean.
     */
    self.isVisibleForWholeSite = function() {
        return self.getSetup($mmSite.getSiteHomeId()).then(function(response) {
            return response.contextmode == mmaXpContextSystem
                && response.block
                && response.block.visible
                && response.perms
                && response.perms.canaccess;
        }).catch(function() {
            return false;
        });
    };

    return self;
});
