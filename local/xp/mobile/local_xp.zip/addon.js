angular.module('mm.addons.xp', [])
.constant('mmaXpVersion', '1.0.1')
.constant('mmaXpCoursesNavPriority', 1)
.constant('mmaXpSideMenuNavPriority', 1)
.constant('mmaXpNavIcon', 'ion-ios-game-controller-b')
.constant('mmaXpGroupChangedEvent', 'mma-xp-group-changed')
.constant('mmaXpContextSystem', 10)
.constant('mmaXpContextCourse', 50)
.constant('mmaXpRankModeOff', 0)
.constant('mmaXpRankModeOn', 1)
.constant('mmaXpRankModeRel', 2)
.config(["$stateProvider", "$mmCoursesDelegateProvider", "mmaXpCoursesNavPriority", "$mmSideMenuDelegateProvider", "mmaXpSideMenuNavPriority", function($stateProvider, $mmCoursesDelegateProvider, mmaXpCoursesNavPriority,
        $mmSideMenuDelegateProvider, mmaXpSideMenuNavPriority) {
    $stateProvider
    .state('site.xp', {
        url: '/xp',
        views: {
            'site': {
                templateUrl: '$ADDONPATH$/templates/index.html',
                controller: 'mmaXpIndexCtrl'
            }
        },
        params: {
            courseid: null,
        }
    });
    $mmCoursesDelegateProvider.registerNavHandler('mmaXp', '$mmaXpHandlers.coursesNav',
        mmaXpCoursesNavPriority);
    $mmSideMenuDelegateProvider.registerNavHandler('mmaXp', '$mmaXpHandlers.sideMenuNav',
        mmaXpSideMenuNavPriority);
}]);

angular.module('mm.addons.xp')
.controller('mmaXpHomeCtrl', ["$scope", "$stateParams", "$mmaXp", "$mmSite", "$q", function($scope, $stateParams, $mmaXp, $mmSite, $q) {
    var courseId = $stateParams.courseid || $mmSite.getSiteHomeId(),
        setup;
    $scope.courseId = courseId;
    $scope.description = '';
    $scope.loaded = false;
    var refresh = function() {
        var promises = [
            $mmaXp.invalidateRecentActivityCache(courseId),
            $mmaXp.invalidateUserStateCache(courseId),
        ];
        $q.all(promises).then(function() {
            return loadView();
        }).finally(function() {
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.refresh = refresh;
    var loadView = function() {
        return $mmaXp.getSetup(courseId).then(function(setup) {
            $scope.description = setup.block && setup.block.description ? setup.block.description : '';
            $scope.recentactivity = false;
            if ((setup.block && setup.block.recentactivity) || setup.perms.canmanage) {
                $scope.recentactivity = true;
            }
            var raPromise = loadRecentActivity();
            var usPromise = loadUserState();
            return $q.all([usPromise, raPromise]);
        })
    };
    var loadRecentActivity = function() {
        return $mmaXp.getRecentActivity(courseId).then(function(response) {
            $scope.recentactivityitems = response;
        });
    };
    var loadUserState = function() {
        return $mmaXp.getUserState(courseId).then(function(response) {
            $scope.userState = response;
            $scope.percentage = parseFloat(response.ratioinlevel) * 100;
            $scope.xptogo = response.totalxpinlevel - response.xpinlevel;
        });
    };
    loadView().finally(function() {
        $scope.loaded = true;
    });
}]);

angular.module('mm.addons.xp')
.controller('mmaXpIndexCtrl', ["$scope", "$stateParams", "$mmaXp", "$mmSite", function($scope, $stateParams, $mmaXp, $mmSite) {
    var courseId = $stateParams.courseid || $mmSite.getSiteHomeId();
    $scope.courseId = courseId;
    $scope.title = $mmaXp.getTitle(courseId);
    $scope.loaded = false;
    $scope.hasInfo = false;
    $scope.addonPath = '$ADDONPATH$';
    $mmaXp.getSetup(courseId).then(function(setup) {
        $scope.hasInfo = setup.config && setup.config.enableinfos;
        $scope.hasLadder = setup.config && setup.config.enableladder;
        $scope.showTabs = $scope.hasInfo || $scope.hasLadder;
    }).finally(function() {
        $scope.loaded = true;
    });
}]);

angular.module('mm.addons.xp')
.controller('mmaXpInfoCtrl', ["$scope", "$stateParams", "$mmaXp", "$mmSite", function($scope, $stateParams, $mmaXp, $mmSite) {
    var courseId = $stateParams.courseid || $mmSite.getSiteHomeId();
    $scope.courseId = courseId;
    $scope.loaded = false;
    $mmaXp.getLevelsInfo(courseId).then(function(levelsinfo) {
        $scope.levelsinfo = levelsinfo;
    }).finally(function() {
        $scope.loaded = true;
    });
}]);

angular.module('mm.addons.xp')
.controller('mmaXpLadderCtrl', ["$scope", "$stateParams", "$mmEvents", "$mmaXp", "$mmSite", "$mmaXpGroups", "$mmUtil", "$timeout", "$ionicScrollDelegate", "mmaXpRankModeOn", "mmaXpRankModeRel", "mmaXpGroupChangedEvent", function($scope, $stateParams, $mmEvents, $mmaXp, $mmSite, $mmaXpGroups, $mmUtil,
        $timeout, $ionicScrollDelegate, mmaXpRankModeOn, mmaXpRankModeRel, mmaXpGroupChangedEvent) {
    var courseId = $stateParams.courseid || $mmSite.getSiteHomeId(),
        userId = $mmSite.getUserId(),
        groupId = 0,
        perpage = 20,
        page = 0,
        minPageLoaded,
        refreshing = false,
        groupChangeEventObserver,
        scrollView = $ionicScrollDelegate.$getByHandle('mmaXpLadderScroll');;
    $scope.loadingMore = false;
    $scope.userId = userId;
    $scope.courseId = courseId;
    $scope.loaded = false;
    $scope.hasMore = false;
    $scope.ranks = [];
    $scope.getItemClasses = function(state) {
        if (state.id == userId) {
            return 'is-me';
        }
        return '';
    }
    var updateMinPageLoaded = function(page) {
        if (!page) {
            return;
        } else if (!minPageLoaded) {
            minPageLoaded = page;
            return;
        }
        minPageLoaded = Math.min(page, minPageLoaded);
    }
    var getShowTotal = function(ladder) {
        var showTotal = false;
        angular.forEach(ladder.columns, function(col) {
            showTotal = showTotal || col == 'xp';
        });
        return showTotal;
    }
    var loadView = function() {
        minPageLoaded = null;
        page = 0;
        return $mmaXp.getLadder(courseId, groupId, page, perpage).then(function(ladder) {
            page = ladder.page;
            updateMinPageLoaded(page);
            $scope.showRank = ladder.rankmode == mmaXpRankModeOn;
            $scope.showRelRank = ladder.rankmode == mmaXpRankModeRel;
            $scope.showTotal = getShowTotal(ladder);
            $scope.ranks = ladder.ranking;
            $scope.hasMore = !ladder.neighbours && (ladder.page * perpage < ladder.total);
            $scope.hasBefore = minPageLoaded > 1;
        });
    }
    $scope.refresh = function() {
        refreshing = true;
        $mmaXp.invalidateLadderCache(courseId, groupId).then(function() {
            return loadView();
        }).finally(function() {
            refreshing = false;
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.loadBefore = function() {
        if ($scope.loadingBefore || refreshing) {
            return;
        }
        $scope.loadingBefore = true;
        $mmaXp.getLadder(courseId, groupId, minPageLoaded - 1, perpage).then(function(ladder) {
            updateMinPageLoaded(ladder.page);
            var ranks = ladder.ranking;
            angular.forEach($scope.ranks, function(rank) {
                ranks.push(rank);
            })
            $scope.ranks = ranks;
            $scope.hasBefore = minPageLoaded > 1;
        }).finally(function() {
            $scope.loadingBefore = false;
        });
    }
    $scope.loadMore = function() {
        if ($scope.loadingMore || refreshing) {
            return;
        }
        page += 1;
        $scope.loadingMore = true;
        $mmaXp.getLadder(courseId, groupId, page, perpage).then(function(ladder) {
            angular.forEach(ladder.ranking, function(rank) {
                $scope.ranks.push(rank);
            })
            $scope.hasMore = !ladder.neighbours && (ladder.page * perpage < ladder.total);
        }).finally(function() {
            $scope.loadingMore = false;
        });
    };
    groupChangeEventObserver = $mmEvents.on(mmaXpGroupChangedEvent, function(data) {
        groupId = data.groupId;
        loadView();
    });
    $scope.$on('$destroy', function() {
        groupChangeEventObserver && groupChangeEventObserver.off && groupChangeEventObserver.off();
    });
    $mmaXpGroups.getCurrentGroupId(courseId).then(function(grpId) {
        groupId = grpId;
        return loadView();
    }).finally(function() {
        $timeout(function() {
            $mmUtil.scrollToElement(document, '.is-me', scrollView);
        }, 300);
        $scope.loaded = true;
    });
}]);

angular.module('mm.addons.xp')
.directive('mmaXpGroupSelector', ["$mmGroups", "$mmaXpGroups", "$q", function($mmGroups, $mmaXpGroups, $q) {
    return {
        restrict: 'E',
        templateUrl: '$ADDONPATH$/templates/group-selector.html',
        scope: {
            courseid: '=',
        },
        link: function(scope, element, attrs) {
            var courseId = scope.courseid;
            scope.loaded = false;
            scope.enabled = false;
            scope.groups = [];
            scope.data = {}
            $mmaXpGroups.isCourseUsingGroups(courseId).then(function(enabled) {
                if (!enabled) {
                    return $q.reject();
                }
                return $q.all([
                    $mmaXpGroups.getCourseGroupInfo(courseId),
                    $mmaXpGroups.getCurrentGroupId(courseId),
                ]).then(function(data) {
                    var groupinfo = data[0],
                        currentGroupId = data[1],
                        groups = groupinfo.groups,
                        canseeall = groupinfo.canseeallparticipants,
                        selectedGroupCandidates = groups.filter(function(group) { return group.id == currentGroupId }),
                        selectedGroup = selectedGroupCandidates[0] ? selectedGroupCandidates[0] : null;
                    scope.canseeallpart = canseeall;
                    scope.groups = groups;
                    scope.mygroups = groups.filter(function(group) {
                        return group.ismember;
                    });
                    scope.othergroups = groups.filter(function(group) {
                        return !group.ismember;
                    });
                    scope.canswitch = groups.length > 1 || groups.length == 1 && canseeall;
                    scope.usesvisiblegroups = groupinfo.groupmode == $mmGroups.VISIBLEGROUPS;
                    scope.usesseparategroups = groupinfo.groupmode == $mmGroups.SEPARATEGROUPS;
                    scope.data.currentGroupId = "" + currentGroupId;  
                    scope.onChange = function() {
                        $mmaXpGroups.setCurrentGroupId(courseId, parseInt(scope.data.currentGroupId, 10));
                    }
                    scope.selectedGroupName = selectedGroup ? selectedGroup.name : '[Unknown]';
                });
            }).then(function() {
                scope.enabled = true;
            }).catch(function() {
                scope.enabled = false;
            }).finally(function() {
                scope.loaded = true;
            });
        }
    };
}]);

angular.module('mm.addons.xp')
.directive('mmaXpLevel', function() {
    return {
        restrict: 'E',
        templateUrl: '$ADDONPATH$/templates/level.html',
        scope: {
            level: '=',
        },
        link: function(scope, element, attrs) {
            scope.getCssClasses = function(level) {
                var cssClasses = [];
                cssClasses.push('level-' + level.level);
                if (level.badgeurl) {
                    cssClasses.push('level-badge');
                }
                return cssClasses.join(' ');
            }
            scope.wrapperClasses = 'mma-xp-level';
            if (attrs.size) {
                scope.wrapperClasses += ' ' + attrs.size;
            }
        }
    };
});

angular.module('mm.addons.xp')
.directive('mmaXpXp', ["$mmaXp", function($mmaXp) {
    return {
        restrict: 'E',
        templateUrl: '$ADDONPATH$/templates/xp.html',
        scope: {
            courseid: '=',
            amount: '='
        },
        link: function(scope, element, attrs) {
            $mmaXp.getSetup(scope.courseid).then(function(response) {
                scope.currency = response.visuals.currency;
            });
        }
    };
}]);

angular.module('mm.addons.xp')
.factory('$mmaXpGroups', ["$mmEvents", "$mmSite", "$mmGroups", "$log", "$q", "mmaXpGroupChangedEvent", function($mmEvents, $mmSite, $mmGroups, $log, $q, mmaXpGroupChangedEvent) {
    $log = $log.getInstance('$mmaXpGroups');
    var self = {},
        currentGroup = {};
    self.getCourseGroupInfo = function(courseId) {
        return $mmSite.read('local_xp_get_course_group_info', {courseid: courseId}).then(function(data) {
            return data;
        });
    }
    self.getCourseGroupMode = function(courseId) {
        var p;
        if (courseId == $mmSite.getSiteHomeId()) {
            p = $q.when($mmGroups.NOGROUPS);
        } else {
            p = self.getCourseGroupInfo(courseId).then(function(course) {
                return course.groupmode;
            });
        }
        return p.then(function(groupmode) {
            $log.debug("Found course " + courseId + " group mode to be: " + groupmode);
            return groupmode;
        }).catch(function() {
            $log.debug("Could not determine group mode of course: " + courseId);
            return $q.reject();
        })
    }
    self.getCurrentGroupId = function(courseId) {
        var siteId = $mmSite.getId(),
            groupId;
        if (typeof currentGroup[siteId] === 'undefined') {
            currentGroup[siteId] = {};
        }
        if (courseId == $mmSite.getSiteHomeId()) {
            return $q.when(0);
        }
        groupId = currentGroup[siteId][courseId];
        if (typeof groupId === 'undefined') {
            groupId = self.getCourseGroupInfo(courseId).then(function(info) {
                if (info.groupmode == $mmGroups.NOGROUPS) {
                    return 0;
                } else if (info.canaccessallgroups) {
                    return 0;
                }
                var memberIn = info.groups.filter(function(group) { return group.ismember; });
                if (memberIn.length && typeof memberIn[0] !== 'undefined') {
                    return memberIn[0].id;
                }
                return 0;
            });
        }
        return $q.when(groupId).then(function(groupId) {
            currentGroup[siteId][courseId] = groupId;
            return groupId;
        });
    }
    self.isCourseUsingGroups = function(courseId) {
        return self.getCourseGroupMode(courseId).then(function(groupmode) {
            return groupmode != $mmGroups.NOGROUPS;
        });
    }
    self.setCurrentGroupId = function(courseId, groupId) {
        var siteId = $mmSite.getId()
        if (typeof currentGroup[siteId] === 'undefined') {
            currentGroup[siteId] = {};
        }
        currentGroup[siteId][courseId] = groupId || 0;
        $mmEvents.trigger(mmaXpGroupChangedEvent, {
            siteId: siteId,
            courseId: courseId,
            groupId: currentGroup[siteId][courseId]
        });
        $log.debug("Setting current group for course " + courseId + " to: " + currentGroup[siteId][courseId]);
    }
    return self;
}]);

angular.module('mm.addons.xp')
.factory('$mmaXpHandlers', ["$mmaXp", "$q", "$log", "$mmSite", "mmaXpNavIcon", function($mmaXp, $q, $log, $mmSite, mmaXpNavIcon) {
    $log = $log.getInstance('$mmaXpHandlers');
    var self = {};
    self.sideMenuNav = function() {
        var self = {};
        self.isEnabled = function() {
            $log.debug('sideMenuNav::isEnabled()');
            if ($mmaXp.isPluginEnabled()) {
                return $mmaXp.isVisibleForWholeSite().then(function(enabled) {
                    $log.debug('sideMenuNav::isEnabled() responded: ' + enabled);
                    return enabled;
                });
            }
            $log.debug('sideMenuNav::isEnabled() responded: false');
            return false;
        };
        self.getController = function() {
            return function($scope, $state) {
                var courseId = $mmSite.getSiteHomeId();
                $scope.icon = mmaXpNavIcon;
                $scope.title = $mmaXp.getTitle(courseId);
                $scope.class = 'mma-xp-handler';
                $scope.state = 'site.xp';
            };
        };
        return self;
    };
    self.coursesNav = function() {
        var self = {};
        self.isEnabled = function() {
            $log.debug('coursesNav::isEnabled()');
            if ($mmaXp.isPluginEnabled()) {
                return $mmaXp.isForWholeSite().then(function(enabled) {
                    enabled = !enabled;
                    $log.debug('coursesNav::isEnabled() responded: ' + enabled);
                    return enabled;
                });
            }
            $log.debug('coursesNav::isEnabled() responded: false');
            return false;
        };
        self.isEnabledForCourse = function(courseId, accessData, navOptions, admOptions) {
            $log.debug('coursesNav::isEnabledForCourse()');
            return $mmaXp.isVisibleForCourse(courseId).then(function(enabled) {
                $log.debug('coursesNav::isEnabledForCourse() responded: ' + enabled);
                return enabled;
            });
        };
        self.getController = function(courseId) {
            return function($scope, $state) {
                $scope.icon = mmaXpNavIcon;
                $scope.title = $mmaXp.getTitle(courseId);
                $scope.class = 'mma-xp-handler';
                $scope.action = function($event, course) {
                    $event.preventDefault();
                    $event.stopPropagation();
                    $state.go('site.xp', {
                        courseid: course.id
                    });
                };
            };
        };
        return self;
    }
    return self;
}]);

angular.module('mm.addons.xp')
.factory('$mmaXp', ["$mmWS", "$mmSite", "$log", "$translate", "mmaXpContextSystem", function($mmWS, $mmSite, $log, $translate, mmaXpContextSystem) {
    $log = $log.getInstance('$mmaXp');
    var self = {},
        optimisticSetupCache = {};
    function getCachedSetup(courseId) {
        return optimisticSetupCache[courseId];
    }
    function getCacheKeyForSetup(courseId) {
        return 'mmaXp:setup:' + courseId;
    }
    function getCacheKeyForLadder(courseId, groupId, page, perpage) {
        var key = 'mmaXp:ladder:' + courseId + ':' + groupId;
        if (typeof page !== 'undefined') {
            key += ':' + page + ':' + perpage;
        }
        return key;
    }
    function getCacheKeyForRecentActivity(courseId) {
        return 'mmaXp:recentActivity:' + courseId;
    }
    function getCacheKeyForUserState(courseId, userId) {
        return 'mmaXp:userState:' + courseId + ':' + userId;
    }
    function fixCurrencyUrls(currency) {
        if (currency && currency.signurl) {
            currency.signurl = $mmSite.fixPluginfileURL(currency.signurl);
        }
        return currency;
    }
    function fixLevelUrls(level) {
        if (level && level.badgeurl) {
            level.badgeurl = $mmSite.fixPluginfileURL(level.badgeurl);
        }
        return level;
    }
    function fixRankUrls(rank) {
        if (rank && rank.state) {
            rank.state = fixLevelUrls(rank.state);
        }
        return rank;
    }
    function fixStateUrls(state) {
        if (state && state.level) {
            state.level = fixLevelUrls(state.level);
        }
        return state;
    }
    self.getLadder = function(courseId, groupId, page, perpage) {
        groupId = groupId || 0;
        page = page || 0;
        perpage = perpage || 20;
        var presets = {
            cacheKey: getCacheKeyForLadder(courseId, groupId, page, perpage)
        };
        $log.debug('Calling ladder method for course, group: ' + courseId + ', ' + groupId);
        return $mmSite.read('local_xp_get_course_world_ladder', {
            courseid: courseId,
            groupid: groupId,
            page: page,
            perpage: perpage
        }, presets).then(function(response) {
            response.ranking = response.ranking.map(function(rank) {
                return fixRankUrls(rank);
            });
            return response;
        });
    }
    self.getLevelsInfo = function(courseId) {
        $log.debug('Calling levels method for course: ' + courseId);
        return $mmSite.read('local_xp_get_levels_info', {courseid: courseId}).then(function(response) {
            response.levels = response.levels.map(function(level) {
                return fixLevelUrls(level);
            });
            return response;
        });
    }
    self.getRecentActivity = function(courseId) {
        var presets = {
            cacheKey: getCacheKeyForRecentActivity(courseId)
        };
        $log.debug('Calling recent activity method for course: ' + courseId);
        return $mmSite.read('local_xp_get_recent_activity', {courseid: courseId}, presets).then(function(response) {
            return response;
        });
    };
    self.getSetup = function(courseId) {
        var presets = {
            cacheKey: getCacheKeyForSetup(courseId)
        };
        $log.debug('Calling setup method for course: ' + courseId);
        return $mmSite.read('local_xp_get_setup', {courseid: courseId}, presets).then(function(response) {
            if (response && response.visuals && response.visuals.currency) {
                response.visuals.currency = fixCurrencyUrls(response.visuals.currency);
            }
            optimisticSetupCache[courseId] = response;
            return response;
        });
    };
    self.getTitle = function(courseId) {
        var setup = getCachedSetup(courseId);
        if (!setup || !setup.block || !setup.block.title) {
            return $translate.instant('mma.xp.levelup');
        }
        return setup.block.title;
    }
    self.getUserState = function(courseId,  userId) {
        userId = userId || $mmSite.getUserId();
        var presets = {
            cacheKey: getCacheKeyForUserState(courseId, userId)
        }
        return $mmSite.read('local_xp_get_user_state', {courseid: courseId, userid: userId}, presets).then(function(state) {
            return fixStateUrls(state);
        });
    };
    self.invalidateLadderCache = function(courseId, groupId) {
        return $mmSite.invalidateWsCacheForKeyStartingWith(getCacheKeyForLadder(courseId, groupId));
    };
    self.invalidateRecentActivityCache = function(courseId) {
        return $mmSite.invalidateWsCacheForKey(getCacheKeyForRecentActivity(courseId));
    };
    self.invalidateSetupCache = function(courseId) {
        return $mmSite.invalidateWsCacheForKey(getCacheKeyForSetup(courseId));
    };
    self.invalidateUserStateCache = function(courseId, userId) {
        userId = userId || $mmSite.getUserId();
        return $mmSite.invalidateWsCacheForKey(getCacheKeyForUserState(courseId, userId));
    };
    self.isForWholeSite = function() {
        return self.getSetup($mmSite.getSiteHomeId()).then(function(response) {
            return response.contextmode == mmaXpContextSystem;
        }).catch(function() {
            return false;
        });
    }
    self.isPluginEnabled = function() {
        var enabled = false;
        if ($mmSite.isLoggedIn() && $mmSite.wsAvailable('local_xp_get_setup', false)) {
            enabled = true;
        }
        $log.debug(enabled ? 'Plugin is enabled.' : 'Plugin is disabled.');
        return enabled;
    };
    self.isVisibleForCourse = function(courseId) {
        return self.getSetup(courseId).then(function(response) {
            return response.contextmode != mmaXpContextSystem
                && response.block
                && response.block.visible
                && response.perms
                && response.perms.canaccess;
        }).catch(function() {
            return false;
        });
    };
    self.isVisibleForWholeSite = function() {
        return self.getSetup($mmSite.getSiteHomeId()).then(function(response) {
            return response.contextmode == mmaXpContextSystem
                && response.block
                && response.block.visible
                && response.perms
                && response.perms.canaccess;
        }).catch(function() {
            return false;
        });
    };
    return self;
}]);
