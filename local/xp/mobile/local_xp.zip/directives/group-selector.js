// (C) Copyright 2017 Frédéric Massart
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.xp')

/**
 * Directive to render XP.
 */
.directive('mmaXpGroupSelector', function($mmGroups, $mmaXpGroups, $q) {
    return {
        restrict: 'E',
        templateUrl: 'addons/xp/templates/group-selector.html',
        scope: {
            courseid: '=',
        },
        link: function(scope, element, attrs) {
            var courseId = scope.courseid;

            scope.loaded = false;
            scope.enabled = false;
            scope.groups = [];
            scope.data = {}

            $mmaXpGroups.isCourseUsingGroups(courseId).then(function(enabled) {
                if (!enabled) {
                    return $q.reject();
                }
                return $q.all([
                    $mmaXpGroups.getCourseGroupInfo(courseId),
                    $mmaXpGroups.getCurrentGroupId(courseId),
                ]).then(function(data) {
                    var groupinfo = data[0],
                        currentGroupId = data[1],
                        groups = groupinfo.groups,
                        canseeall = groupinfo.canseeallparticipants,
                        selectedGroupCandidates = groups.filter(function(group) { return group.id == currentGroupId }),
                        selectedGroup = selectedGroupCandidates[0] ? selectedGroupCandidates[0] : null;

                    scope.canseeallpart = canseeall;
                    scope.groups = groups;
                    scope.mygroups = groups.filter(function(group) {
                        return group.ismember;
                    });
                    scope.othergroups = groups.filter(function(group) {
                        return !group.ismember;
                    });
                    scope.canswitch = groups.length > 1 || groups.length == 1 && canseeall;
                    scope.usesvisiblegroups = groupinfo.groupmode == $mmGroups.VISIBLEGROUPS;
                    scope.usesseparategroups = groupinfo.groupmode == $mmGroups.SEPARATEGROUPS;
                    scope.data.currentGroupId = "" + currentGroupId;  // Use string for <option> value matching.
                    scope.onChange = function() {
                        $mmaXpGroups.setCurrentGroupId(courseId, parseInt(scope.data.currentGroupId, 10));
                    }
                    scope.selectedGroupName = selectedGroup ? selectedGroup.name : '[Unknown]';
                });
            }).then(function() {
                scope.enabled = true;
            }).catch(function() {
                scope.enabled = false;
            }).finally(function() {
                scope.loaded = true;
            });
        }
    };
});
