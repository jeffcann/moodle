#!/bin/sh

# Do we want to move the file somewhere after building it?
MOVETO=$1
if [ -n "$MOVETO" ]; then
    MOVETO=$(readlink -f $MOVETO)
fi

# Identify the absolute path.
ADDONDIR=$(pwd)
if [ ! -f "main.js" ]; then
    echo "You must be in the addon's root folder."
    exit 2
fi

# Navigate to Ionic root.
cd ../../../
IONICDIR=$(pwd)
if [ ! -f "ionic.project" ]; then
    echo "Parent path does not look like Moodle Mobile."
    exit 1
fi

# Prepare paths.
SCSSFILE="$ADDONDIR/scss/styles.scss"
SCSSORIG=${SCSSFILE}.orig
ADDONPATH=${ADDONDIR#${IONICDIR}/}
ADDONNAME=${ADDONPATH#www/addons/}
BUILDFILE=$ADDONDIR/$ADDONNAME.zip

# Prepare new styles file.
echo "Patching SCSS file"
cp $SCSSFILE $SCSSORIG
echo '$mma-xp-path: "";' > $SCSSFILE
cat $SCSSORIG >> $SCSSFILE

# Check if an existing build is present.
if [ -f $BUILDFILE ]; then
    echo "Removing previous build file"
    rm $BUILDFILE
fi

# Build addon.
echo "Building remote addon"
gulp remoteaddon -p $ADDONPATH

# Restore styles file.
echo "Restoring SCSS file"
mv $SCSSORIG $SCSSFILE

# Done.
echo "Remote addon built at:"
echo $BUILDFILE

# Moving to destination.
if [ -n "$MOVETO" ]; then
    if [ -d "$MOVETO" ]; then
        MOVETO="$MOVETO/$ADDONNAME.zip"
    fi
    if [ -f "$MOVETO" ]; then
        echo "Moving aborted: the destination file already exists."
        echo "  $MOVETO"
        exit 3
    fi

    echo "Moving build file to:"
    echo $MOVETO
    mv $BUILDFILE $MOVETO
fi

