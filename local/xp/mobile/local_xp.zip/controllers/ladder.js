// (C) Copyright 2017 Frédéric Massart
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.xp')

.controller('mmaXpLadderCtrl', function($scope, $stateParams, $mmEvents, $mmaXp, $mmSite, $mmaXpGroups, $mmUtil,
        $timeout, $ionicScrollDelegate, mmaXpRankModeOn, mmaXpRankModeRel, mmaXpGroupChangedEvent) {

    // Wo do not always get the course ID, we must be in the whole site mode.
    var courseId = $stateParams.courseid || $mmSite.getSiteHomeId(),
        userId = $mmSite.getUserId(),
        groupId = 0,
        perpage = 20,
        page = 0,
        minPageLoaded,
        refreshing = false,
        groupChangeEventObserver,
        scrollView = $ionicScrollDelegate.$getByHandle('mmaXpLadderScroll');;

    // We might inherit from the parent scope, so redefine everything.
    $scope.loadingMore = false;
    $scope.userId = userId;
    $scope.courseId = courseId;
    $scope.loaded = false;
    $scope.hasMore = false;
    $scope.ranks = [];
    $scope.getItemClasses = function(state) {
        if (state.id == userId) {
            return 'is-me';
        }
        return '';
    }

    // Update the lowest page loaded.
    var updateMinPageLoaded = function(page) {
        if (!page) {
            return;
        } else if (!minPageLoaded) {
            minPageLoaded = page;
            return;
        }
        minPageLoaded = Math.min(page, minPageLoaded);
    }

    var getShowTotal = function(ladder) {
        var showTotal = false;
        angular.forEach(ladder.columns, function(col) {
            showTotal = showTotal || col == 'xp';
        });
        return showTotal;
    }

    // Load the view.
    var loadView = function() {
        minPageLoaded = null;
        page = 0;
        return $mmaXp.getLadder(courseId, groupId, page, perpage).then(function(ladder) {
            page = ladder.page;
            updateMinPageLoaded(page);

            $scope.showRank = ladder.rankmode == mmaXpRankModeOn;
            $scope.showRelRank = ladder.rankmode == mmaXpRankModeRel;
            $scope.showTotal = getShowTotal(ladder);
            $scope.ranks = ladder.ranking;
            $scope.hasMore = !ladder.neighbours && (ladder.page * perpage < ladder.total);
            $scope.hasBefore = minPageLoaded > 1;
        });
    }

    // Define refresh method.
    $scope.refresh = function() {
        refreshing = true;
        $mmaXp.invalidateLadderCache(courseId, groupId).then(function() {
            return loadView();
        }).finally(function() {
            refreshing = false;
            $scope.$broadcast('scroll.refreshComplete');
        });
    };

    // Load before.
    $scope.loadBefore = function() {
        if ($scope.loadingBefore || refreshing) {
            return;
        }
        $scope.loadingBefore = true;
        $mmaXp.getLadder(courseId, groupId, minPageLoaded - 1, perpage).then(function(ladder) {
            updateMinPageLoaded(ladder.page);
            var ranks = ladder.ranking;
            angular.forEach($scope.ranks, function(rank) {
                ranks.push(rank);
            })
            $scope.ranks = ranks;
            $scope.hasBefore = minPageLoaded > 1;
        }).finally(function() {
            $scope.loadingBefore = false;
        });
    }

    // Function to load more items.
    $scope.loadMore = function() {
        if ($scope.loadingMore || refreshing) {
            return;
        }
        page += 1;
        $scope.loadingMore = true;
        $mmaXp.getLadder(courseId, groupId, page, perpage).then(function(ladder) {
            angular.forEach(ladder.ranking, function(rank) {
                $scope.ranks.push(rank);
            })
            $scope.hasMore = !ladder.neighbours && (ladder.page * perpage < ladder.total);
        }).finally(function() {
            $scope.loadingMore = false;
        });
    };

    // Observe group changes.
    groupChangeEventObserver = $mmEvents.on(mmaXpGroupChangedEvent, function(data) {
        groupId = data.groupId;
        loadView();
    });
    $scope.$on('$destroy', function() {
        groupChangeEventObserver && groupChangeEventObserver.off && groupChangeEventObserver.off();
    });

    // Get the initial ladder.
    $mmaXpGroups.getCurrentGroupId(courseId).then(function(grpId) {
        groupId = grpId;
        return loadView();
    }).finally(function() {
        $timeout(function() {
            $mmUtil.scrollToElement(document, '.is-me', scrollView);
        }, 300);
        $scope.loaded = true;
    });
});
