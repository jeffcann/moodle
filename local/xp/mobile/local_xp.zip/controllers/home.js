// (C) Copyright 2017 Frédéric Massart
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.xp')

.controller('mmaXpHomeCtrl', function($scope, $stateParams, $mmaXp, $mmSite, $q) {
    // Wo do not always get the course ID, we must be in the whole site mode.
    var courseId = $stateParams.courseid || $mmSite.getSiteHomeId(),
        setup;

    // We might inherit from the parent scope, so redefine everything.
    $scope.courseId = courseId;
    $scope.description = '';
    $scope.loaded = false;

    // Define refresh method.
    var refresh = function() {
        var promises = [
            $mmaXp.invalidateRecentActivityCache(courseId),
            $mmaXp.invalidateUserStateCache(courseId),
        ];
        $q.all(promises).then(function() {
            return loadView();
        }).finally(function() {
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.refresh = refresh;

    // Load the view data.
    var loadView = function() {
        return $mmaXp.getSetup(courseId).then(function(setup) {
            $scope.description = setup.block && setup.block.description ? setup.block.description : '';
            $scope.recentactivity = false;
            if ((setup.block && setup.block.recentactivity) || setup.perms.canmanage) {
                $scope.recentactivity = true;
            }
            var raPromise = loadRecentActivity();
            var usPromise = loadUserState();
            return $q.all([usPromise, raPromise]);
        })
    };

    // Load recent activity.
    var loadRecentActivity = function() {
        return $mmaXp.getRecentActivity(courseId).then(function(response) {
            $scope.recentactivityitems = response;
        });
    };

    // Load user state.
    var loadUserState = function() {
        return $mmaXp.getUserState(courseId).then(function(response) {
            $scope.userState = response;
            $scope.percentage = parseFloat(response.ratioinlevel) * 100;
            $scope.xptogo = response.totalxpinlevel - response.xpinlevel;
        });
    };

    // Load view function.
    loadView().finally(function() {
        $scope.loaded = true;
    });

});
